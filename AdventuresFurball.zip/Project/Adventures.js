/*	***************************************
	*	Author: Jacqueline Sauter Forseck *
	*	Date: November 20, 2014			  *
	***************************************
*/

function Furball(x, y)
{
	'use strict';
	
	this.x = x;
	this.y = y;
	this.width = 67;
	this.height = 78;
	
	this.draw = function()
	{
		drawFurball(this.x, this.y);
	};
}

function Hairless(x, y)
{
	'use strict';
	
	this.x = x;
	this.y = y;
	this.width = 40;
	this.height = 56;
	this.speed = 2;
	
	this.draw = function()
	{
		drawHairless(this.x, this.y);
	};
	
	this.moveRight = function()
	{
		this.x += this.speed;
	};
	
	this.moveLeft = function()
	{
		this.x -= this.speed;
	};
	
	this.moveUp = function()
	{
		this.y -= this.speed;
	};
	
	this.moveDown = function()
	{
		this.y += this.speed;
	};
	
	// Event handler function for Hairless object
	this.move = function(event)
	{
		var key = event.which;
		
		if(key == 37)
		{
			this.moveLeft();
		}
		else if(key == 38)
		{
			this.moveUp();
		}
		else if(key == 39)
		{
			this.moveRight();
		}
		else if(key == 40)
		{
			this.moveDown();
		}
	};
}

function Fluffy(x, y)
{
	'use strict';
	
	this.x = x;
	this.y = y;
	this.width = 20;
	this.height = 18;
	this.draw = function()
	{
		drawFluffy(this.x, this.y);
	};
}

function drawFurball(x, y)
{
	var canvas = document.getElementById("canvas");
	var c = canvas.getContext("2d");
	
	c.strokeStyle = "rgb(0, 0, 0)";
	c.beginPath();
	c.moveTo(x + 30, y + 17);
	c.lineTo(x + 20, y + 0);
	c.lineTo(x + 18, y + 19);
	c.lineTo(x + 5, y + 11);
	c.lineTo(x + 12, y + 27);
	c.lineTo(x + 0, y + 33);
	c.lineTo(x + 10, y + 38);
	c.lineTo(x + 5, y + 48);
	c.lineTo(x + 21, y + 42);
	c.lineTo(x + 13, y + 56);
	c.lineTo(x + 20, y + 60);
	c.lineTo(x + 25, y + 50);
	c.lineTo(x + 22, y + 68);
	c.lineTo(x + 17, y + 71);
	c.lineTo(x + 24, y + 75);
	c.lineTo(x + 29, y + 69);
	c.lineTo(x + 32, y + 59);
	c.lineTo(x + 34, y + 59);
	c.lineTo(x + 39, y + 72);
	c.lineTo(x + 43, y + 78);
	c.lineTo(x + 50, y + 73);
	c.lineTo(x + 44, y + 70);
	c.lineTo(x + 41, y + 50);
	c.lineTo(x + 46, y + 61);
	c.lineTo(x + 52, y + 57);
	c.lineTo(x + 42, y + 42);
	c.lineTo(x + 61, y + 48);
	c.lineTo(x + 53, y + 38);
	c.lineTo(x + 66, y + 34);
	c.lineTo(x + 52, y + 27);
	c.lineTo(x + 56, y + 9);
	c.lineTo(x + 44, y + 21);
	c.lineTo(x + 38, y + 0);
	c.closePath();
	c.stroke();
	
	c.fillStyle = "rgb(185, 122, 87)";
	c.fill();
	
	c.fillStyle = "rgb(0, 162, 232)";
	c.fillRect(x + 27, y + 32, 4, 4);
	c.fillRect(x + 34, y + 32, 4, 4);
}

function drawHairless(x, y)
{
	'use strict';
	
	var canvas = document.getElementById("canvas");
	var c = canvas.getContext("2d");
	
	c.strokeStyle = "rgb(0, 0, 0)";
	
	c.beginPath();
	c.arc(x + 19, y + 12, 12, 0, 2 * Math.PI);
	c.stroke();
	
	c.fillStyle = "rgb(251, 224, 196)";
	c.fill();
	
	c.beginPath();
	c.moveTo(x + 9, y + 20);
	c.lineTo(x + 0, y + 34);
	c.lineTo(x + 7, y + 38);
	c.lineTo(x + 12, y + 28);
	c.lineTo(x + 9, y + 46);
	c.lineTo(x + 5, y + 49);
	c.lineTo(x + 11, y + 53);
	c.lineTo(x + 15, y + 48);
	c.lineTo(x + 19, y + 37);
	c.lineTo(x + 21, y + 37);
	c.lineTo(x + 25, y + 49);
	c.lineTo(x + 30, y + 55);
	c.lineTo(x + 37, y + 51);
	c.lineTo(x + 31, y + 48);
	c.lineTo(x + 28, y + 28);
	c.lineTo(x + 33, y + 38);
	c.lineTo(x + 39, y + 35);
	c.lineTo(x + 29, y + 20);
	c.fill();
	c.stroke();
	
	c.fillStyle = "rgb(94, 57, 38)";
	c.fillRect(x + 14, y + 10, 4, 4);
	c.fillRect(x + 21, y + 10, 4, 4);
}

function drawFluffy(x, y)
{
	'use strict';
	
	var canvas = document.getElementById("canvas");
	var c = canvas.getContext("2d");
	var filling = "rgb(185, 122, 87)";
	
	drawCircle(c, filling, x + 4, y + 5, 4);
	c.stroke();
	drawCircle(c, filling, x + 12, y + 4, 4);
	c.stroke();
	drawCircle(c, filling, x + 17, y + 9, 3);
	c.stroke();
	drawCircle(c, filling, x + 15, y + 14, 3);
	c.stroke();
	drawCircle(c, filling, x + 8, y + 15, 4);
	c.stroke();
	drawCircle(c, filling, x + 3, y + 11, 3);
	c.stroke();
	drawCircle(c, filling, x + 10, y + 9, 5);
}

function drawCircle(context, colour, centerX, centerY, radius)
{
	'use strict';
	
	context.fillStyle = colour;
	
	context.beginPath();
	context.arc(centerX, centerY, radius, 0, 2 * Math.PI);
	context.fill();
}

function moveFurball()
{
	'use strict';
	
}

function getDifficulty(event)
{
	'use strict';
	
	if(event.target.id == "easy")
	{
		
	}
	else if(event.target.id == "medium")
	{
		
	}
	else
	{
		
	}
}

function init()
{
	'use strict';
	
	var easyButton = document.getElementById("easy");
	var medButton = document.getElementById("medium");
	var hardButton = document.getElementById("hard");
	var player = new Hairless(50, 50);
	
	displayBackground();
	//window.setInterval(drawEverything, 100);
	
	easyButton.addEventListener('click', getDifficulty, false);
	medButton.addEventListener('click', getDifficulty, false);
	hardButton.addEventListener('click', getDifficulty, false);
	
	// Event listener for player's key presses
	window.addEventListener('keydown', player.move, false);
}

function displayBackground()
{
	'use strict';
	
	var canvas = document.getElementById("canvas");
	var c = canvas.getContext("2d");
	
	c.fillStyle = "rgb(255, 255, 255)";
	c.rect(0, 0, canvas.width, canvas.height);
	c.fill();
	c.stroke();
}

// Note: Every time anything moves, the background, the player, the fluffies and Furball need to 
// be re-drawn all at once, 
function drawEverything(furball, hairless, fluffies)
{
	'use strict';
	
	displayBackground();
	furball.draw();
	hairless.draw();
	
	for(var item = 0; item < fluffies.length; item++)
	{
		fluffies[item].draw();
	}
	
}

window.addEventListener('load', init, false);